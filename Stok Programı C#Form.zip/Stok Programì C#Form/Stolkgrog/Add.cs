﻿using QRCoder;
using Stolkgrog.Data;
using Stolkgrog.DesingPaterms;
using Stolkgrog.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;

namespace Stolkgrog
{
    public partial class Add : Form
    {
        public Add()
        {
            InitializeComponent();
        }
        byte[] ConvertImageToBinary(Image img)
        {
            if (img != null)
            {
                using (MemoryStream ms = new MemoryStream())
                {
                    img.Save(ms, System.Drawing.Imaging.ImageFormat.Jpeg);
                    return ms.ToArray();
                }
            }
            return new byte[0];
        }
        DataConnection db = DBTooll.DBInstance;
        Product product = new Product();
        private void Kaydet_Click(object sender, EventArgs e)
        {
            try
            {
                XmlDocument xmlVerisi = new XmlDocument();
                xmlVerisi.Load("http://www.tcmb.gov.tr/kurlar/today.xml");
                decimal dolar = Convert.ToDecimal(xmlVerisi.SelectSingleNode(string.Format("Tarih_Date/Currency[@Kod='{0}']/ForexSelling", "USD")).InnerText.Replace('.', ','));
                var catagory = db.Maincatagory.SingleOrDefault(x => x.MainCategory == ktgr.Text);
                List<Product> products = db.products.Select(x => x).ToList();
                if (!string.IsNullOrEmpty(ad.Text) || !string.IsNullOrEmpty(brk.Text) || !string.IsNullOrEmpty(stk.Text) || !string.IsNullOrEmpty(richTextBox6.Text) || !string.IsNullOrEmpty(alıs.Text) || !string.IsNullOrEmpty(sts.Text))
                {
                    product.Name = ad.Text;
                    product.Barcode = brk.Text;
                    product.Quantity = Convert.ToInt32(stk.Text);
                    //product.Purchase_price = Convert.ToInt32(alıs.Text);
                    //product.Sale_Price = Convert.ToInt32(sts.Text);
                    product.product_description = richTextBox6.Text;
                    product.MainCatagory = catagory;
                    product.ProductImageData = ConvertImageToBinary(rsm.Image);
                    product.profit = 0;
                    product.damage = 0;
                    product.Creat_Time = DateTime.Now;
                    if (alıs.TextLength != 0 && sts.TextLength != 0)
                    {


                        if (checkBox1.Checked)
                        {

                            decimal dolarr = Convert.ToDecimal(dolar);
                            decimal alıss = Convert.ToDecimal(alıs.Text);
                            decimal cvp = dolarr * alıss;
                            decimal stss = Convert.ToDecimal(sts.Text);
                            decimal cvp2 = dolarr * stss;
                            product.Purchase_price = Convert.ToInt32(cvp);
                            product.Sale_Price = Convert.ToInt32(cvp2);
                            product.Creat_Time = DateTime.Now;
                        }
                    }
                    if (checkBox2.Checked)
                    {
                        product.Purchase_price = Convert.ToInt32(alıs.Text);
                        product.Sale_Price = Convert.ToInt32(sts.Text);

                    }
                    db.products.Add(product);
                    db.SaveChanges();
                    MessageBox.Show("Ürününüz Kayıt Edildi", "confirmation", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    this.Close();


                }
                else
                {
                    MessageBox.Show("Lütfen Bilgileirnizi Kontrol Edin !");
                }
            }
            catch (Exception)
            {

                MessageBox.Show("Lütfen Tekrar Deneyin");
            }



            //dolar

            //var catagory = db.Maincatagory.SingleOrDefault(x => x.MainCategory == ktgr.Text);

            ////son
            ////eşitleme
            //if (brk.TextLength != 0)
            //{
            //    product.Barcode = brk.Text;

            //}
            //if (ad.TextLength != 0)
            //{
            //    product.Name = ad.Text;

            //}
            //if (stk.TextLength != 0)
            //{
            //    product.Quantity = Convert.ToInt32(stk.Text);

            //}
            //product.MainCatagory= catagory;
            //product.product_description = richTextBox6.Text;
            //product.ProductImageData = ConvertImageToBinary(rsm.Image);


            ////son
            ////veritabanına ekleme
            //if (!string.IsNullOrEmpty(brk.Text) && !string.IsNullOrEmpty(ad.Text) && !string.IsNullOrEmpty(ktgr.Text) && !string.IsNullOrEmpty(alıs.Text) && !string.IsNullOrEmpty(sts.Text) && !string.IsNullOrEmpty(stk.Text))
            //{
            //    db.products.Add(product);
            //    db.SaveChanges();
            //    //this.Close();
            //}
            //else
            //{
            //    MessageBox.Show("Lütfen Bilgileri Tam ve Doğru Şekilde Girdiğinizden Emin Olun", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
            //}
        }
        private void qra()
        {
            Random random = new Random();
            int a = random.Next();
            string s = Convert.ToString(a);
            QRCodeGenerator qr = new QRCodeGenerator();
            QRCodeData data = qr.CreateQrCode(s, QRCodeGenerator.ECCLevel.Q);
            QRCode code = new QRCode(data);
            brk.Text = s;
            pictureBox2.Image = code.GetGraphic(5);

        }

        private void button4_Click(object sender, EventArgs e)
        {
            qra();
        }
        string fileName;

        private void button5_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog ofd = new OpenFileDialog() { Filter = "PNG(*.png)|*.png|JPG(*.Jpg)|*.jpg", ValidateNames = true, Multiselect = false })
            {
                if (ofd.ShowDialog() == DialogResult.OK)
                {
                    fileName = ofd.FileName;
                    rsm.Image = Image.FromFile(fileName);
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            katagoriadd a = new katagoriadd();
            this.Close();
            a.Show();
        }

        private void Add_Load(object sender, EventArgs e)
        {
            var list = (from x in db.Maincatagory select x).ToList();
            ktgr.ValueMember = "MainCategory";
            ktgr.DataSource = list.ToList();
            checkBox2.Checked = true;
        }

        private void brk_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && e.KeyChar != 8)
            {
                e.Handled = true;
            }
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            string name = ((CheckBox)sender).Name;
            List<string> checks = new List<string> { "checkBox1", "checkBox2" };
            checks.Remove(name);

            foreach (Control control1 in groupBox2.Controls)
            {
                if (checks.Contains(control1.Name) == true)
                {
                    ((CheckBox)control1).Checked = false;
                }

            }
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
            Home h = new Home();
            h.Close();
            h.Show();
        }

        private void Add_FormClosing(object sender, FormClosingEventArgs e)
        {
            Home h = new Home();
            h.Show();
        }
    }
}
