﻿using Stolkgrog.Data;
using Stolkgrog.DesingPaterms;
using Stolkgrog.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Stolkgrog
{
    public partial class Admin : Form
    {
        public Admin()
        {
            InitializeComponent();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            Login l = new Login();
            l.Show();
            this.Close();
        }
        Loginn loginnn = new Loginn();
        DataConnection db = DBTooll.DBInstance;
        private void button1_Click(object sender, EventArgs e)
        {
            string hashedpassword = encryption.ComputeSha256Hash(password.Text);
            loginnn.username = username.Text;
            loginnn.Password = hashedpassword;
            db.logins.Add(loginnn);

            MainCatagory category = new MainCatagory();
            category.MainCategory = "(Default)";
            db.Maincatagory.Add(category);

            db.SaveChanges();
            MessageBox.Show("bilgiler kaydedildi");
        }
    }
}
