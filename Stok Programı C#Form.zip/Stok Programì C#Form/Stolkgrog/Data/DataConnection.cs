﻿using Stolkgrog.Model;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Stolkgrog.Data
{
    public class DataConnection : DbContext
    {
        public DbSet<Loginn> logins { get; set; }
        public DbSet<Product> products { get; set; }
        public DbSet<MainCatagory> Maincatagory { get; set; }
    }
}
