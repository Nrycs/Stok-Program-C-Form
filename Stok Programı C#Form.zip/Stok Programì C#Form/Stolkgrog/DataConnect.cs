﻿namespace Stolkgrog
{
    internal class DataConnect
    {
    }
}