﻿using Stolkgrog.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Stolkgrog.DesingPaterms
{
    public class DBTooll
    {
        static DataConnection _dbInstance;

        public static DataConnection DBInstance
        {
            get
            {
                if (_dbInstance == null)
                {
                    _dbInstance = new DataConnection();
                }
                return _dbInstance;
            }
        }
    }
}
