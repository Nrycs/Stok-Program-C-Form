﻿namespace Stolkgrog
{
    partial class Home
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Home));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.songuncele = new System.Windows.Forms.DataGridView();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.sy = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.ktgrayar = new System.Windows.Forms.Button();
            this.lst = new System.Windows.Forms.Button();
            this.blg = new System.Windows.Forms.Button();
            this.sts = new System.Windows.Forms.Button();
            this.giris = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.songuncele)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.LightGray;
            this.groupBox1.Controls.Add(this.pictureBox2);
            this.groupBox1.Controls.Add(this.songuncele);
            this.groupBox1.Controls.Add(this.dataGridView2);
            this.groupBox1.Controls.Add(this.groupBox3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.groupBox1.Location = new System.Drawing.Point(12, 126);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1189, 610);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(1135, 0);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(54, 46);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 99;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click_1);
            // 
            // songuncele
            // 
            this.songuncele.AllowUserToAddRows = false;
            this.songuncele.AllowUserToDeleteRows = false;
            this.songuncele.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.songuncele.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.songuncele.BackgroundColor = System.Drawing.Color.Gainsboro;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.MenuHighlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.songuncele.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.songuncele.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.songuncele.Location = new System.Drawing.Point(775, 46);
            this.songuncele.Margin = new System.Windows.Forms.Padding(4);
            this.songuncele.MultiSelect = false;
            this.songuncele.Name = "songuncele";
            this.songuncele.ReadOnly = true;
            this.songuncele.RowHeadersWidth = 51;
            this.songuncele.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.songuncele.ShowCellErrors = false;
            this.songuncele.ShowEditingIcon = false;
            this.songuncele.ShowRowErrors = false;
            this.songuncele.Size = new System.Drawing.Size(393, 526);
            this.songuncele.TabIndex = 96;
            // 
            // dataGridView2
            // 
            this.dataGridView2.AllowUserToAddRows = false;
            this.dataGridView2.AllowUserToDeleteRows = false;
            this.dataGridView2.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView2.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dataGridView2.BackgroundColor = System.Drawing.Color.Gainsboro;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.MenuHighlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView2.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Location = new System.Drawing.Point(7, 45);
            this.dataGridView2.Margin = new System.Windows.Forms.Padding(4);
            this.dataGridView2.MultiSelect = false;
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.ReadOnly = true;
            this.dataGridView2.RowHeadersWidth = 51;
            this.dataGridView2.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView2.ShowCellErrors = false;
            this.dataGridView2.ShowEditingIcon = false;
            this.dataGridView2.ShowRowErrors = false;
            this.dataGridView2.Size = new System.Drawing.Size(393, 526);
            this.dataGridView2.TabIndex = 95;
            // 
            // groupBox3
            // 
            this.groupBox3.BackColor = System.Drawing.Color.Transparent;
            this.groupBox3.Controls.Add(this.sy);
            this.groupBox3.Controls.Add(this.label4);
            this.groupBox3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.groupBox3.Location = new System.Drawing.Point(417, 58);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(352, 98);
            this.groupBox3.TabIndex = 3;
            this.groupBox3.TabStop = false;
            // 
            // sy
            // 
            this.sy.AutoSize = true;
            this.sy.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.sy.Location = new System.Drawing.Point(251, 37);
            this.sy.Name = "sy";
            this.sy.Size = new System.Drawing.Size(79, 32);
            this.sy.TabIndex = 6;
            this.sy.Text = "1000";
            this.sy.Click += new System.EventHandler(this.sy_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label4.Location = new System.Drawing.Point(8, 37);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(243, 29);
            this.label4.TabIndex = 7;
            this.label4.Text = "Toplam Ürün Sayısı =";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(772, 26);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(155, 17);
            this.label2.TabIndex = 5;
            this.label2.Text = "En son Güncellenen\'ler";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(14, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(126, 17);
            this.label1.TabIndex = 4;
            this.label1.Text = "En son Eklenen\'ler";
            // 
            // ktgrayar
            // 
            this.ktgrayar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ktgrayar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ktgrayar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ktgrayar.Image = ((System.Drawing.Image)(resources.GetObject("ktgrayar.Image")));
            this.ktgrayar.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.ktgrayar.Location = new System.Drawing.Point(609, 21);
            this.ktgrayar.Name = "ktgrayar";
            this.ktgrayar.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.ktgrayar.Size = new System.Drawing.Size(114, 99);
            this.ktgrayar.TabIndex = 94;
            this.ktgrayar.Text = "Ürün Lisatesi";
            this.ktgrayar.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.ktgrayar.UseVisualStyleBackColor = false;
            this.ktgrayar.Click += new System.EventHandler(this.ktgrayar_Click);
            // 
            // lst
            // 
            this.lst.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.lst.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lst.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lst.Image = ((System.Drawing.Image)(resources.GetObject("lst.Image")));
            this.lst.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.lst.Location = new System.Drawing.Point(459, 21);
            this.lst.Name = "lst";
            this.lst.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.lst.Size = new System.Drawing.Size(114, 99);
            this.lst.TabIndex = 93;
            this.lst.Text = "Ürün Lisatesi";
            this.lst.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.lst.UseVisualStyleBackColor = false;
            this.lst.Click += new System.EventHandler(this.lst_Click);
            // 
            // blg
            // 
            this.blg.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.blg.Cursor = System.Windows.Forms.Cursors.Hand;
            this.blg.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.blg.Image = ((System.Drawing.Image)(resources.GetObject("blg.Image")));
            this.blg.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.blg.Location = new System.Drawing.Point(162, 21);
            this.blg.Name = "blg";
            this.blg.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.blg.Size = new System.Drawing.Size(114, 99);
            this.blg.TabIndex = 92;
            this.blg.Text = "Ürün Bilgileri";
            this.blg.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.blg.UseVisualStyleBackColor = false;
            this.blg.Click += new System.EventHandler(this.blg_Click);
            // 
            // sts
            // 
            this.sts.BackColor = System.Drawing.Color.Transparent;
            this.sts.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.sts.Cursor = System.Windows.Forms.Cursors.Hand;
            this.sts.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.sts.Image = ((System.Drawing.Image)(resources.GetObject("sts.Image")));
            this.sts.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.sts.Location = new System.Drawing.Point(312, 21);
            this.sts.Name = "sts";
            this.sts.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.sts.Size = new System.Drawing.Size(114, 99);
            this.sts.TabIndex = 91;
            this.sts.Text = "Satış İşlemleri";
            this.sts.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.sts.UseVisualStyleBackColor = false;
            this.sts.Click += new System.EventHandler(this.sts_Click);
            // 
            // giris
            // 
            this.giris.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.giris.Cursor = System.Windows.Forms.Cursors.Hand;
            this.giris.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.giris.Image = ((System.Drawing.Image)(resources.GetObject("giris.Image")));
            this.giris.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.giris.Location = new System.Drawing.Point(12, 21);
            this.giris.Name = "giris";
            this.giris.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.giris.Size = new System.Drawing.Size(114, 99);
            this.giris.TabIndex = 90;
            this.giris.Text = "Ürün Girişi";
            this.giris.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.giris.UseVisualStyleBackColor = false;
            this.giris.Click += new System.EventHandler(this.giris_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(1173, -1);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(52, 46);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 98;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // Home
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Gainsboro;
            this.ClientSize = new System.Drawing.Size(1223, 749);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.ktgrayar);
            this.Controls.Add(this.lst);
            this.Controls.Add(this.blg);
            this.Controls.Add(this.sts);
            this.Controls.Add(this.giris);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Home";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Home";
            this.Load += new System.EventHandler(this.Home_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.songuncele)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label sy;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button ktgrayar;
        private System.Windows.Forms.Button lst;
        private System.Windows.Forms.Button blg;
        private System.Windows.Forms.Button sts;
        private System.Windows.Forms.Button giris;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.DataGridView songuncele;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.PictureBox pictureBox2;
    }
}