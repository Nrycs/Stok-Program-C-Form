﻿using Stolkgrog.Data;
using Stolkgrog.DesingPaterms;
using Stolkgrog.dtos;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Stolkgrog
{
    public partial class Home : Form
    {
        public Home()
        {
            InitializeComponent();
        }
        DataConnection db = DBTooll.DBInstance;
        private void giris_Click(object sender, EventArgs e)
        {
            var b = this.Location;
            Add a = new Add();
            a.Show();
            a.Location = b;
        }      
        

        private void yenile()
        {



            try
            {
                int kayitsayisi = db.products.Count();
                sy.Text = kayitsayisi.ToString();
                List<ProductRefleshDto> list_dto = new List<ProductRefleshDto>();

                List<Product> products = db.products.Select(x => x).OrderByDescending(x => x.Creat_Time).ToList();

                foreach (Product product in products.Take(5))
                {
                    ProductRefleshDto dto = new ProductRefleshDto();
                    dto.İsim = product.Name;
                    dto.Katagori = product.MainCatagory.MainCategory;
                    dto.Miktar = product.Quantity;

                    list_dto.Add(dto);
                }
                this.dataGridView2.DataSource = list_dto.ToList();
                ////////
                List<Product> productss = db.products.Where(x => x.Modified_Time!=null).OrderByDescending(x => x.Modified_Time).ToList();

                List<ProductRefleshDto> list_dtoo = new List<ProductRefleshDto>();

                foreach (Product productt in productss.Take(5))
                {
                    ProductRefleshDto dto = new ProductRefleshDto();

                    dto.İsim = productt.Name;
                    dto.Katagori = productt.MainCatagory.MainCategory;
                    dto.Miktar = productt.Quantity;
                    list_dtoo.Add(dto);
                }
                this.songuncele.DataSource = list_dtoo.ToList();
                songuncele.Columns["Id"].Visible = false;
                dataGridView2.Columns["Id"].Visible = false;




            }
            catch (Exception)
            {
                MessageBox.Show("Sunucuya bağlanılamadı ! ", "error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.Close();

            }
        }
        private void Home_Load(object sender, EventArgs e)
        {
            yenile();
        }

        private void blg_Click(object sender, EventArgs e)
        {
            Liste l = new Liste();
            l.Show();
            var b = this.Location;
            l.Location = b;
        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void sts_Click(object sender, EventArgs e)
        {
            Sale s =new Sale();
            s.Show();
            var b = this.Location;
            s.Location = b;
        }

        private void lst_Click(object sender, EventArgs e)
        {
            Productsss p = new Productsss();
            p.Show();
            var b = this.Location;
            p.Location = b;
        }

        private void ktgrayar_Click(object sender, EventArgs e)
        {
            katagori k = new katagori();
            k.Show();
            var b = this.Location;
            k.Location = b;
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            Application.Exit();
            this.MinimizeBox = true;
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            var largeSize = new Size(320, 490);
            this.Size = largeSize;

        }

        private void pictureBox2_Click_1(object sender, EventArgs e)
        {
            yenile();
        }

        private void sy_Click(object sender, EventArgs e)
        {

        }
    }
}
