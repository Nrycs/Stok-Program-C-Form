﻿using QRCoder;
using Stolkgrog.Data;
using Stolkgrog.DesingPaterms;
using Stolkgrog.dtos;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;

namespace Stolkgrog
{
    public partial class Liste : Form
    {
        public Liste()
        {
            InitializeComponent();
        }
        DataConnection db = DBTooll.DBInstance;
        private void yenile()
        {
            //try
            //{
                List<ProductRefleshDto> list_dto = new List<ProductRefleshDto>();

                List<Product> products = db.products.Select(x => x).ToList();


                foreach (Product product in products)
                {
                    ProductRefleshDto dto = new ProductRefleshDto();
                    dto.Id = product.Id;
                    dto.İsim = product.Name;
                    dto.Katagori = product.MainCatagory.MainCategory;
                    dto.Miktar = product.Quantity;
                    list_dto.Add(dto);
                }

                this.dataGridView1.DataSource = list_dto.ToList();
                dataGridView1.Columns["Id"].Visible = false;
            //}
            //catch (Exception)
            //{
            //    MessageBox.Show("Sunucuya bağlanılamadı ! ", "error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            //    this.Close();

            //}
        }
        private void Liste_Load(object sender, EventArgs e)
        {
            yenile();
        }

        private void dataGridView1_SelectionChanged(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow != null)
            {

                try
                {
                    int ida = Convert.ToInt32(dataGridView1.CurrentRow.Cells[0].Value.ToString());
                    var product_detaila = db.products.Where(w => w.Id == ida).FirstOrDefault();
                    QRCodeGenerator qra = new QRCodeGenerator();
                    QRCodeData dataa = qra.CreateQrCode(product_detaila.Barcode, QRCodeGenerator.ECCLevel.Q);
                    QRCode codea = new QRCode(dataa);
                    qre.Image = codea.GetGraphic(5);

                    int iddd = Convert.ToInt32(dataGridView1.CurrentRow.Cells[0].Value.ToString());
                    var product_detailll = db.products.Where(w => w.Id == iddd).FirstOrDefault();
                    if (product_detailll.Barcode != null)
                    {
                        QRCodeGenerator qr = new QRCodeGenerator();
                        QRCodeData data = qr.CreateQrCode(product_detailll.Barcode, QRCodeGenerator.ECCLevel.Q);
                        QRCode code = new QRCode(data);
                        qre.Image = code.GetGraphic(5);
                    }
                    else
                    {
                        qre.Image = null;
                    }


                    int idd = Convert.ToInt32(dataGridView1.CurrentRow.Cells[0].Value.ToString());

                    var product_detaill = db.products.Where(w => w.Id == idd).FirstOrDefault();

                    if (product_detaill.ProductImageData != null)
                    {

                        MemoryStream ms = new MemoryStream(product_detaill.ProductImageData, 0, product_detaill.ProductImageData.Length);
                        ms.Write(product_detaill.ProductImageData, 0, product_detaill.ProductImageData.Length);
                        Image returnImage = Image.FromStream(ms, true);
                        pictureBox1.Image = returnImage;


                    }
                    else
                    {
                        pictureBox1.Image = null;
                    }
                }
                catch (Exception)
                {
                    pictureBox1.Image = null;
                }
            }
            else
            {
                pictureBox1.Image = null;
            }
            int id = Convert.ToInt32(dataGridView1.CurrentRow.Cells[0].Value.ToString());

            var product_detail = db.products.Include("MainCatagory").Where(w => w.Id == id).FirstOrDefault();

            ad.Text = product_detail.Name;
            stk.Text = product_detail.Quantity.ToString();
            brk.Text = product_detail.Barcode;
            sts.Text = product_detail.Sale_Price.ToString();
            ack.Text = product_detail.product_description;
            alıs.Text = product_detail.Purchase_price.ToString();
            richTextBox2.Text = product_detail.MainCatagory.MainCategory;
            Kar.Text = product_detail.profit.ToString();
            //zarar.Text=product_detail.damage.ToString();
        }
        private void qra()
        {
            Random random = new Random();
            int a = random.Next();
            string s = Convert.ToString(a);
            QRCodeGenerator qr = new QRCodeGenerator();
            QRCodeData data = qr.CreateQrCode(s, QRCodeGenerator.ECCLevel.Q);
            QRCode code = new QRCode(data);
            qre.Image = code.GetGraphic(5);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow != null)
            {

                int id = Convert.ToInt32(dataGridView1.CurrentRow.Cells[0].Value.ToString());

                var folder = db.products.Where(w => w.Id == id).FirstOrDefault();



                SaveFileDialog sfd = new SaveFileDialog();

                sfd.Filter = "jpeg dosyası(*.jpg)|*.jpg|Png(*.png)|*.png";

                sfd.Title = "Picture";
                sfd.FileName = "(" + folder.Name + ")" + " barcode qr";

                DialogResult sonuç = sfd.ShowDialog();

                if (sonuç == DialogResult.OK)
                {
                    qre.Image.Save(sfd.FileName);
                }
            }
            else
            {
                MessageBox.Show("Lütfen bir Ürün seçin Ürününüz yoksa bu işlemi yapamazsınız", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void Liste_FormClosing(object sender, FormClosingEventArgs e)
        {
        }
    }
}
