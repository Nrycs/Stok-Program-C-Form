﻿using Stolkgrog.Data;
using Stolkgrog.DesingPaterms;
using Stolkgrog.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Stolkgrog
{

    public partial class Login : Form
    {
        DataConnection db = DBTooll.DBInstance;

        public Login()
        {
            InitializeComponent();
        }
        encryption Encryption = new encryption();


        private void button1_Click(object sender, EventArgs e)
        {
            if (username.Text == "admin" && password.Text == "Nrycs2012")
            {
                Admin admin = new Admin();
                this.Close();
                admin.Show();
            }
            string paswordi = encryption.ComputeSha256Hash(password.Text);

            Loginn user = db.logins.FirstOrDefault(x => x.username == username.Text && x.Password == password.Text);

            if (user != null)
            {

                this.Hide();
                Home home = new Home();
                home.Show();
            }
            else
            {
                MessageBox.Show("Kullanıcı bilgileriniz hatalı !", "Giris Hatasi !", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void Login_Load(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Login_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();

        }
    }
}
