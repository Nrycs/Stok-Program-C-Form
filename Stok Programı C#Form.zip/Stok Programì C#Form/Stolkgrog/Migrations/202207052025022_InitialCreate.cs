﻿namespace Stolkgrog.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class InitialCreate : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Loginns",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        username = c.String(),
                        Password = c.String(),
                    })
                .PrimaryKey(t => t.Id);
            
            CreateTable(
                "dbo.MainCatagories",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        MainCategory = c.String(),
                    })
                .PrimaryKey(t => t.Id);
            
            CreateTable(
                "dbo.Products",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        Name = c.Int(nullable: false),
                        Quantity = c.Int(nullable: false),
                        Barcode = c.Int(nullable: false),
                        Sale_Price = c.Int(nullable: false),
                        product_description = c.Int(nullable: false),
                        Purchase_price = c.Int(nullable: false),
                        profit = c.Int(nullable: false),
                        damage = c.Int(nullable: false),
                        MainCatagory_Id = c.Int(),
                    })
                .PrimaryKey(t => t.Id)
                .ForeignKey("dbo.MainCatagories", t => t.MainCatagory_Id)
                .Index(t => t.MainCatagory_Id);
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.Products", "MainCatagory_Id", "dbo.MainCatagories");
            DropIndex("dbo.Products", new[] { "MainCatagory_Id" });
            DropTable("dbo.Products");
            DropTable("dbo.MainCatagories");
            DropTable("dbo.Loginns");
        }
    }
}
