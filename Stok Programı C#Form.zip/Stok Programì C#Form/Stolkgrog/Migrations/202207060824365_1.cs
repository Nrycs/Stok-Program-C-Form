﻿namespace Stolkgrog.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class _1 : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.Products", "Creat_Time", c => c.DateTime(nullable: false));
            AddColumn("dbo.Products", "Modified_Time", c => c.DateTime(nullable: false));
            AlterColumn("dbo.Products", "Name", c => c.String());
            AlterColumn("dbo.Products", "Barcode", c => c.String());
            AlterColumn("dbo.Products", "product_description", c => c.String());
        }
        
        public override void Down()
        {
            AlterColumn("dbo.Products", "product_description", c => c.Int(nullable: false));
            AlterColumn("dbo.Products", "Barcode", c => c.Int(nullable: false));
            AlterColumn("dbo.Products", "Name", c => c.Int(nullable: false));
            DropColumn("dbo.Products", "Modified_Time");
            DropColumn("dbo.Products", "Creat_Time");
        }
    }
}
