﻿namespace Stolkgrog.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class _2 : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.Products", "ProductImageData", c => c.Binary());
            AddColumn("dbo.Products", "filln", c => c.Binary());
        }
        
        public override void Down()
        {
            DropColumn("dbo.Products", "filln");
            DropColumn("dbo.Products", "ProductImageData");
        }
    }
}
