﻿namespace Stolkgrog.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class _4 : DbMigration
    {
        public override void Up()
        {
            AlterColumn("dbo.Products", "Modified_Time", c => c.DateTime());
        }
        
        public override void Down()
        {
            AlterColumn("dbo.Products", "Modified_Time", c => c.DateTime(nullable: false));
        }
    }
}
