﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Stolkgrog.Model
{
    public class MainCatagory
    {
        public int Id { get; set; }
        public string MainCategory { get; set; }
    }
}
