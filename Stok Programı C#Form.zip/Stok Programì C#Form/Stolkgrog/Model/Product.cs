﻿using Stolkgrog.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Stolkgrog
{
    public class Product
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int Quantity { get; set; }
        public string Barcode { get; set; }
        public int Sale_Price { get; set; }
        public string product_description { get; set; }
        public int Purchase_price { get; set; }
        public int profit { get; set; }
        public int damage { get; set; }
        public DateTime Creat_Time { get; set; }
        public DateTime? Modified_Time { get; set; }
        public byte[] ProductImageData { get; set; }
        public byte[] filln { get; set; }
        //
        public virtual MainCatagory MainCatagory { get; set; }

    }
}
