﻿using QRCoder;
using Stolkgrog.Data;
using Stolkgrog.DesingPaterms;
using Stolkgrog.dtos;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;

namespace Stolkgrog
{
    public partial class Productsss : Form
    {
        public Productsss()
        {
            InitializeComponent();
        }
        DataConnection db = DBTooll.DBInstance;
        private void yenile()
        {
            var list = (from x in db.Maincatagory select x).ToList();
            comboBox1.ValueMember = "MainCategory";
            this.comboBox1.DataSource = list.ToList();
            //try
            //{
                List<ProductRefleshDto> list_dto = new List<ProductRefleshDto>();

                List<Product> products = db.products.Select(x => x).ToList();


                foreach (Product product in products)
                {
                    ProductRefleshDto dto = new ProductRefleshDto();
                    dto.Id = product.Id;
                    dto.İsim = product.Name;
                    dto.Katagori = product.MainCatagory.MainCategory;
                    dto.Miktar = product.Quantity;
                    list_dto.Add(dto);
                }

                this.dataGridView1.DataSource = list_dto.ToList();
                dataGridView1.Columns["Id"].Visible = false;

            //}
            //catch (Exception)
            //{
            //    MessageBox.Show("Sunucuya bağlanılamadı ! ", "error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            //    this.Close();

            //}
        }
        private void button4_Click(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow != null)
            {

                int id = Convert.ToInt32(dataGridView1.CurrentRow.Cells[0].Value.ToString());

                var folder = db.products.Where(w => w.Id == id).FirstOrDefault();



                SaveFileDialog sfd = new SaveFileDialog();

                sfd.Filter = "jpeg dosyası(*.jpg)|*.jpg|Png(*.png)|*.png";

                sfd.Title = "Picture";
                sfd.FileName = "(" + folder.Name + ")" + " barcode qr";

                DialogResult sonuç = sfd.ShowDialog();

                if (sonuç == DialogResult.OK)
                {
                    qre.Image.Save(sfd.FileName);
                }
            }
            else
            {
                MessageBox.Show("Lütfen bir Ürün seçin Ürününüz yoksa bu işlemi yapamazsınız", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
        private void Productsss_Load(object sender, EventArgs e)
        {
            checkBox2.Checked = true;
            yenile();
        }
        byte[] ConvertImageToBinary(Image img)
        {
            if (img != null)
            {
                using (MemoryStream ms = new MemoryStream())
                {
                    img.Save(ms, System.Drawing.Imaging.ImageFormat.Jpeg);
                    return ms.ToArray();
                }
            }
            return new byte[0];
        }
        private void button1_Click(object sender, EventArgs e)
        {
            if (a == false)
            {
                XmlDocument xmlVerisi = new XmlDocument();
                xmlVerisi.Load("http://www.tcmb.gov.tr/kurlar/today.xml");
                decimal dolar = Convert.ToDecimal(xmlVerisi.SelectSingleNode(string.Format("Tarih_Date/Currency[@Kod='{0}']/ForexSelling", "USD")).InnerText.Replace('.', ','));
                int id = Convert.ToInt32(dataGridView1.CurrentRow.Cells[0].Value.ToString());
                Product product = new Product();

                Product old_version = new Product();
                Product guncelle = db.products.Where(w => w.Id == id).FirstOrDefault();
                old_version = guncelle;

                guncelle.Quantity = Convert.ToInt32(stk.Text);
                guncelle.Barcode = brk.Text;
                //guncelle.Sale_Price = Convert.ToInt32(sts.Text);,
                if (checkBox1.Checked)
                {

                    decimal dolarr = Convert.ToDecimal(dolar);
                    decimal alıss = Convert.ToDecimal(alıs.Text);
                    decimal cvp = dolarr * alıss;
                    decimal stss = Convert.ToDecimal(sts.Text);
                    decimal cvp2 = dolarr * stss;
                    guncelle.Purchase_price = Convert.ToInt32(cvp);
                    guncelle.Sale_Price = Convert.ToInt32(cvp2);

                }
                guncelle.product_description = ack.Text;
                //guncelle.Purchase_price = Convert.ToInt32(alıs.Text);
                if (checkBox2.Checked)
                {
                    guncelle.Purchase_price = Convert.ToInt32(alıs.Text);
                    guncelle.Sale_Price = Convert.ToInt32(sts.Text);

                }
                guncelle.Name = ad.Text;
                guncelle.MainCatagory.MainCategory = ktgr.Text;
                guncelle.product_description = richTextBox1.Text;
                guncelle.ProductImageData = ConvertImageToBinary(pictureBox1.Image);
                guncelle.Modified_Time = DateTime.Now;
                db.Entry(old_version).CurrentValues.SetValues(guncelle);
                db.SaveChanges();
                yenile();
                ad.Text = String.Empty;
                stk.Text = String.Empty;
                brk.Text = String.Empty;
                sts.Text = String.Empty;
                ack.Text = String.Empty;
                alıs.Text = String.Empty;
                ktgr.Text = String.Empty;
                richTextBox1.Text = String.Empty;
                pictureBox1.Image = null;
                a = true;
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (a == false)
            {
                int id = Convert.ToInt32(dataGridView1.CurrentRow.Cells[0].Value.ToString());
                Product sil = db.products.Where(w => w.Id == id).FirstOrDefault();
                string a = "(" + sil.Name + ")";

                DialogResult sill = MessageBox.Show(a + "İsimli ürünü silmek istiyor musunuz?", "Bilgilendirme Penceresi", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
                if (sill == DialogResult.Yes)
                {
                    if (sil != null)
                    {
                        db.products.Remove(sil);
                        db.SaveChanges();
                        this.Close();

                    }
                }
            }

        }
        string fileName;
        private void button5_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog ofd = new OpenFileDialog() { Filter = "JPEG(*.jpg)|*.jpg|PNG(*.png)|*.png", ValidateNames = true, Multiselect = false })
            {
                if (ofd.ShowDialog() == DialogResult.OK)
                {
                    fileName = ofd.FileName;
                    pictureBox1.Image = Image.FromFile(fileName);
                }
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            if (richTextBox14.Text != null)
            {
                try
                {
                    List<ProductRefleshDto> list_dto = new List<ProductRefleshDto>();
                    string aranan = richTextBox14.Text;

                    List<Product> products = db.products.Where(x => x.Name.ToString().Contains(aranan)).ToList();


                    foreach (Product product in products)
                    {
                        ProductRefleshDto dto = new ProductRefleshDto();
                        dto.Id = product.Id;
                        dto.İsim = product.Name;
                        dto.Katagori = product.MainCatagory.MainCategory;
                        list_dto.Add(dto);
                    }

                    this.dataGridView1.DataSource = list_dto.ToList();
                    dataGridView1.Columns["Id"].Visible = false;

                }
                catch (Exception)
                {
                    MessageBox.Show("Sunucuya bağlanılamadı ! ", "error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    this.Close();

                }
            }

        }
        bool a = true;
        private void dataGridView1_DoubleClick(object sender, EventArgs e)
        {
            a = false;
            if (dataGridView1.CurrentRow != null)
            {

                try
                {
                    int ida = Convert.ToInt32(dataGridView1.CurrentRow.Cells[0].Value.ToString());
                    var product_detaila = db.products.Where(w => w.Id == ida).FirstOrDefault();
                    QRCodeGenerator qra = new QRCodeGenerator();
                    QRCodeData dataa = qra.CreateQrCode(product_detaila.Barcode, QRCodeGenerator.ECCLevel.Q);
                    QRCode codea = new QRCode(dataa);
                    qre.Image = codea.GetGraphic(5);

                    int iddd = Convert.ToInt32(dataGridView1.CurrentRow.Cells[0].Value.ToString());
                    var product_detailll = db.products.Where(w => w.Id == iddd).FirstOrDefault();
                    if (product_detailll.Barcode != null)
                    {
                        QRCodeGenerator qr = new QRCodeGenerator();
                        QRCodeData data = qr.CreateQrCode(product_detailll.Barcode, QRCodeGenerator.ECCLevel.Q);
                        QRCode code = new QRCode(data);
                        qre.Image = code.GetGraphic(5);
                    }
                    else
                    {
                        qre.Image = null;
                    }

                    int idd = Convert.ToInt32(dataGridView1.CurrentRow.Cells[0].Value.ToString());

                    var product_detaill = db.products.Where(w => w.Id == idd).FirstOrDefault();

                    if (product_detaill.ProductImageData != null)
                    {

                        MemoryStream ms = new MemoryStream(product_detaill.ProductImageData, 0, product_detaill.ProductImageData.Length);
                        ms.Write(product_detaill.ProductImageData, 0, product_detaill.ProductImageData.Length);
                        Image returnImage = Image.FromStream(ms, true);
                        pictureBox1.Image = returnImage;


                    }
                    else
                    {
                        pictureBox1.Image = null;
                    }
                }
                catch (Exception)
                {
                    pictureBox1.Image = null;
                }
            }
            else
            {
                pictureBox1.Image = null;
            }
            try
            {
                XmlDocument xmlVerisi = new XmlDocument();
                xmlVerisi.Load("http://www.tcmb.gov.tr/kurlar/today.xml");

                decimal dolar = Convert.ToDecimal(xmlVerisi.SelectSingleNode(string.Format("Tarih_Date/Currency[@Kod='{0}']/ForexSelling", "USD")).InnerText.Replace('.', ','));
            }
            catch (Exception)
            {

            }


            int id = Convert.ToInt32(dataGridView1.CurrentRow.Cells[0].Value.ToString());

            var product_detail = db.products.Include("Maincatagory").Where(w => w.Id == id).FirstOrDefault();
            var list = (from x in db.Maincatagory select x).ToList();
            ktgr.ValueMember = "MainCategory";
            this.ktgr.DataSource = list.ToList();
            ad.Text = product_detail.Name;
            stk.Text = product_detail.Quantity.ToString();
            brk.Text = product_detail.Barcode;
            sts.Text = product_detail.Sale_Price.ToString();
            ack.Text = product_detail.product_description;
            alıs.Text = product_detail.Purchase_price.ToString();
            ktgr.Text = product_detail.MainCatagory.MainCategory;
            
            richTextBox1.Text = product_detail.product_description;
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox1.Text == "(Default)")
            {
                yenile();
            }
            else
            {
                List<ProductRefleshDto> list_dto = new List<ProductRefleshDto>();



                List<Product> products = db.products.Where(x => x.MainCatagory.MainCategory == comboBox1.SelectedValue.ToString()).ToList();

                foreach (Product product in products)
                {
                    ProductRefleshDto dto = new ProductRefleshDto();
                    dto.Id = product.Id;
                    dto.İsim = product.Name;
                    dto.Katagori = product.MainCatagory.MainCategory;


                    list_dto.Add(dto);
                }
                this.dataGridView1.DataSource = list_dto.ToList();
            }
        }

        private void ktgr_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
            if (char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            string name = ((CheckBox)sender).Name;
            List<string> checks = new List<string> { "checkBox1", "checkBox2" };
            checks.Remove(name);

            foreach (Control control1 in groupBox2.Controls)
            {
                if (checks.Contains(control1.Name) == true)
                {
                    ((CheckBox)control1).Checked = false;
                }

            }
        }

        private void brk_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && e.KeyChar != 8)
            {
                e.Handled = true;
            }
        }

        private void Productsss_FormClosing(object sender, FormClosingEventArgs e)
        {

        }
    }
}
