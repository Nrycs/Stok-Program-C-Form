﻿using Stolkgrog.Data;
using Stolkgrog.DesingPaterms;
using Stolkgrog.dtos;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Stolkgrog
{
    public partial class Sale : Form
    {
        public Sale()
        {
            InitializeComponent();
        }
        DataConnection db = DBTooll.DBInstance;
        private void Sale_Load(object sender, EventArgs e)
        {
            try
            {
                List<ProductRefleshDto> list_dto = new List<ProductRefleshDto>();

                List<Product> products = db.products.Select(x => x).ToList();


                foreach (Product product in products)
                {
                    ProductRefleshDto dto = new ProductRefleshDto();
                    dto.Id = product.Id;
                    dto.İsim = product.Name;
                    dto.Katagori = product.MainCatagory.MainCategory;
                    dto.Miktar = product.Quantity;
                    list_dto.Add(dto);
                }

                this.dataGridView1.DataSource = list_dto.ToList();

            }
            catch (Exception)
            {
                MessageBox.Show("Sunucuya bağlanılamadı ! ", "error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.Close();

            }
            groupBox1.Hide();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            
            int ida = Convert.ToInt32(dataGridView1.CurrentRow.Cells[0].Value.ToString());
            var product_detaila = db.products.Where(w => w.Id == ida).FirstOrDefault();
            int cevap1 = product_detaila.Sale_Price * Convert.ToInt32(numericUpDown1.Value);
            int cevap2 = product_detaila.Purchase_price * Convert.ToInt32(numericUpDown1.Value);



            fiyat.Text = cevap1.ToString();
            alısfiyatı.Text = cevap2.ToString();


            if (!string.IsNullOrEmpty(stcfiyat.Text))
            {

                try
                {
                    timer1.Start();
                    hesap.Text = stcfiyat.Text;
                    Double fiyat1 = Convert.ToDouble(alısfiyatı.Text);
                    Double alınan = Convert.ToDouble(stcfiyat.Text);
                    Double kaaar = alınan - fiyat1;
                    kaar.Text=kaaar.ToString();
                    
                }
                catch (Exception)
                {
                    stcfiyat.Text = null;
                    fiyat.Text = null;
                }

            }

            if (numericUpDown1.Value == 0)
            {
                numericUpDown1.Value = 1;
            }
        }
        private void pictureBox4_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(stcfiyat.Text))
            {
                Double fiyat1 = 0.50D;
                string alınan = stcfiyat.Text;
                Double kaaar = Convert.ToDouble(alınan) + fiyat1;
                stcfiyat.Text = kaaar.ToString();
            }
            else
            {
                stcfiyat.Text = 0.50.ToString();
            }

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

            if (!string.IsNullOrEmpty(stcfiyat.Text))
            {
                Double fiyat1 = 200;
                Double alınan = Convert.ToDouble(stcfiyat.Text);
                Double kaaar = alınan + fiyat1;
                stcfiyat.Text = kaaar.ToString();
            }
            else
            {
                stcfiyat.Text = 200.ToString();
            }
        }

        private void fiyat_Click(object sender, EventArgs e)
        {
            groupBox1.Show();
        }

        private void Sale_Click(object sender, EventArgs e)
        {
            groupBox1.Hide();
        }

        private void pictureBox14_Click(object sender, EventArgs e)
        {

            if (!string.IsNullOrEmpty(stcfiyat.Text))
            {
                Double fiyat1 = 100;
                Double alınan = Convert.ToDouble(stcfiyat.Text);
                Double kaaar = alınan + fiyat1;
                stcfiyat.Text = kaaar.ToString();
            }
            else
            {
                stcfiyat.Text = 100.ToString();
            }
        }

        private void pictureBox11_Click(object sender, EventArgs e)
        {

            if (!string.IsNullOrEmpty(stcfiyat.Text))
            {
                Double fiyat1 = 50;
                Double alınan = Convert.ToDouble(stcfiyat.Text);
                Double kaaar = alınan + fiyat1;
                stcfiyat.Text = kaaar.ToString();
            }
            else
            {
                stcfiyat.Text = 50.ToString();
            }
        }

        private void pictureBox10_Click(object sender, EventArgs e)
        {

            if (!string.IsNullOrEmpty(stcfiyat.Text))
            {
                Double fiyat1 = 20;
                Double alınan = Convert.ToDouble(stcfiyat.Text);
                Double kaaar = alınan + fiyat1;
                stcfiyat.Text = kaaar.ToString();
            }
            else
            {
                stcfiyat.Text = 20.ToString();
            }
        }

        private void pictureBox12_Click(object sender, EventArgs e)
        {

            if (!string.IsNullOrEmpty(stcfiyat.Text))
            {
                Double fiyat1 = 10;
                Double alınan = Convert.ToDouble(stcfiyat.Text);
                Double kaaar = alınan + fiyat1;
                stcfiyat.Text = kaaar.ToString();
            }
            else
            {
                stcfiyat.Text = 10.ToString();
            }
        }

        private void pictureBox13_Click(object sender, EventArgs e)
        {

            if (!string.IsNullOrEmpty(stcfiyat.Text))
            {
                Double fiyat1 = 5;
                Double alınan = Convert.ToDouble(stcfiyat.Text);
                Double kaaar = alınan + fiyat1;
                stcfiyat.Text = kaaar.ToString();
            }
            else
            {
                stcfiyat.Text = 5.ToString();
            }
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {

            if (!string.IsNullOrEmpty(stcfiyat.Text))
            {
                Double fiyat1 = 1;
                Double alınan = Convert.ToDouble(stcfiyat.Text);
                Double kaaar = alınan + fiyat1;
                stcfiyat.Text = kaaar.ToString();
            }
            else
            {
                stcfiyat.Text = 1.ToString();
            }
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {

            if (!string.IsNullOrEmpty(stcfiyat.Text))
            {
                Double fiyat1 = 0.25D;
                Double alınan = Convert.ToDouble(stcfiyat.Text);
                Double kaaar = alınan + fiyat1;
                stcfiyat.Text = kaaar.ToString();
            }
            else
            {
                stcfiyat.Text = 0.25.ToString();
            }
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

            if (!string.IsNullOrEmpty(stcfiyat.Text))
            {
                Double fiyat1 = 0.010D;
                Double alınan = Convert.ToDouble(stcfiyat.Text);
                Double kaaar = alınan + fiyat1;
                stcfiyat.Text = kaaar.ToString();
            }
            else
            {
                stcfiyat.Text = 0.010.ToString();
            }
        }

        private void pictureBox6_Click(object sender, EventArgs e)
        {

            if (!string.IsNullOrEmpty(stcfiyat.Text))
            {
                Double fiyat1 = 0.5D;
                Double alınan = Convert.ToDouble(stcfiyat.Text);
                Double kaaar = alınan + fiyat1;
                stcfiyat.Text = kaaar.ToString();
            }
            else
            {
                stcfiyat.Text = 0.5.ToString();
            }
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void pictureBox9_Click(object sender, EventArgs e)
        {

            fiyat.Text = string.Empty;
            kaar.Text = string.Empty;
            hesap.Text = string.Empty;
            stcfiyat.Text = string.Empty;
            groupBox1.Hide();

        }
        private void dataGridView1_SelectionChanged(object sender, EventArgs e)
        {
            fiyat.Text = 1.ToString();
            int a1 = Convert.ToInt32(numericUpDown1.Value);

            int cevap1 = a1 * Convert.ToInt32(fiyat.Text);
            fiyat.Text = cevap1.ToString();





            int ida = Convert.ToInt32(dataGridView1.CurrentRow.Cells[0].Value.ToString());
            var product_detaila = db.products.Where(w => w.Id == ida).FirstOrDefault();

            richTextBox4.Text = product_detaila.Quantity.ToString();
            alısfiyatı.Text = product_detaila.Purchase_price.ToString();
            int a = product_detaila.Sale_Price;
            fiyat.Text = a.ToString();
            alısfiyatı.Text = product_detaila.Purchase_price.ToString();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Product old_version = new Product();
            if (dataGridView1.CurrentRow != null)
            {
                int id = Convert.ToInt32(dataGridView1.CurrentRow.Cells[0].Value.ToString());
                var product_detail = db.products.Where(w => w.Id == id).FirstOrDefault();
                old_version = product_detail;

                if (numericUpDown1.Value <= product_detail.Quantity)
                {
                    if (!string.IsNullOrEmpty(stcfiyat.Text))
                    {




                        DialogResult ekle = MessageBox.Show(numericUpDown1.Value + " " + "sayıda" + " " + product_detail.Name + " " + "isimli Ürünü" + " " + stcfiyat.Text + "Tl" + " ye satıyorsunuz eminmisiniz?", "Information", MessageBoxButtons.OKCancel, MessageBoxIcon.Information);
                        if (ekle == DialogResult.OK)
                        {
                            var a = product_detail.Quantity;
                            var b = numericUpDown1.Value;
                            int miktar = a - Convert.ToInt32(b);
                            product_detail.Quantity = miktar;
                            //var kaaar = product_detail.profit;
                            // int kaaaar = Convert.ToInt32(kaar.Text + kaaar);
                            // product_detail.profit = kaaaar;
                                decimal kaarr = product_detail.profit;
                                decimal sayı = Convert.ToDecimal(kaar.Text);
                                decimal cevap = kaarr + sayı;
                                product_detail.profit = Convert.ToInt32(cevap);
                            db.Entry(old_version).CurrentValues.SetValues(product_detail);
                            db.SaveChanges();
                            MessageBox.Show(numericUpDown1.Value + " " + "sayıda" + " " + product_detail.Name + " " + "isimli Ürününüz" + " " + stcfiyat.Text + " " + "TL'ye satıldı");
                            this.Close();


                        }
                        else
                        {
                            MessageBox.Show("Satma işlemi iptal edildi");
                            this.Close();
                        }

                    }
                    else
                    {
                        MessageBox.Show("Lütfen Satılıcak fiyatı girin");
                    }
                }
                if (product_detail.Quantity == 0)
                {
                    MessageBox.Show("Miktarınız Bitti Ürünü Günceliyebilir yada silebilir siniz");

                }
                else
                {
                    if (numericUpDown1.Value > product_detail.Quantity)
                    {
                        MessageBox.Show("Miktarınız Eksik");
                    }
                }



            }
        }

        private void stcfiyat_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && e.KeyChar != 8 && e.KeyChar != 46)
            {
                e.Handled = true;
            }
        }

        private void Sale_FormClosing(object sender, FormClosingEventArgs e)
        {
            Home h = new Home();
            h.Show();
        }
    }
}
