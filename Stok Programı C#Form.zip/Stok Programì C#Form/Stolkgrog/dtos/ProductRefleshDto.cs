﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Stolkgrog.dtos
{
    public class ProductRefleshDto
    {
        public int Id { get; set; }
        public string İsim { get; set; }
        public string Katagori { get; set; }
        public int Miktar { get; set; }
    }
}
