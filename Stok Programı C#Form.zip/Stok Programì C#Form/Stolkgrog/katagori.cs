﻿using Stolkgrog.Data;
using Stolkgrog.DesingPaterms;
using Stolkgrog.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Stolkgrog
{
    public partial class katagori : Form
    {
        public katagori()
        {
            InitializeComponent();
        }
        DataConnection db = DBTooll.DBInstance;
        MainCatagory main = new MainCatagory();

        private void button3_Click(object sender, EventArgs e)
        {
            main.MainCategory = textBox1.Text;
            db.Maincatagory.Add(main);
            db.SaveChanges();
            MessageBox.Show("Eklendi");
            this.Close();
        }
        private void yenile()
        {
            var list = (from x in db.Maincatagory select x).ToList();
            comboBox1.ValueMember = "MainCategory";
            comboBox1.DataSource = list.ToList();

            var list2 = (from x in db.Maincatagory select x).ToList();
            comboBox2.ValueMember = "MainCategory";
            comboBox2.DataSource = list2.ToList();



        }

        private void katagori_Load(object sender, EventArgs e)
        {
            yenile();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (comboBox2.Text == "(Default)" || comboBox2.Text == "Default" || comboBox2.Text == "default")
            {
                MessageBox.Show("Default katagoriyi günceleyemezsin!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {

                MainCatagory old_version = new MainCatagory();
                MainCatagory guncelle = db.Maincatagory.Where(w => w.MainCategory == comboBox2.Text).FirstOrDefault();


                old_version = guncelle;
                if (guncelle != null)
                {
                    guncelle.MainCategory = textBox2.Text;

                    db.Entry(old_version).CurrentValues.SetValues(guncelle);
                    db.SaveChanges();
                    MessageBox.Show("Katagoriniz Güncellendi", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    this.Close();
                }
                else
                {
                    MessageBox.Show("Böyle bir katagori yok");
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (comboBox2.Text == "(Default)" || comboBox2.Text == "Default" || comboBox2.Text == "default")
            {
                MessageBox.Show("Default katagoriyi silemezsin !", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {


                if (comboBox1.SelectedIndex != -1)
                {

                    var sil = db.Maincatagory.Where(w => w.MainCategory == comboBox1.Text).FirstOrDefault();
                    string a = "(" + comboBox1.Text + ")";
                    DialogResult sill = MessageBox.Show(a + "İsimli Katagoriyi silmek istiyor musunuz?", "Bilgilendirme Penceresi", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
                    if (sill == DialogResult.Yes)
                    {
                        if (sil != null)
                        {
                            DialogResult sirl = MessageBox.Show(a + "İsimli Katagori silindi", "Bilgilendirme Penceresi", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            db.Maincatagory.Remove(sil);
                            db.SaveChanges();
                            this.Close();




                        }
                    }
                }
                else
                {
                    MessageBox.Show("Böyle bir katagori yok");
                }
            }
        }
    }
}
