﻿using Stolkgrog.Data;
using Stolkgrog.DesingPaterms;
using Stolkgrog.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Stolkgrog
{
    public partial class katagoriadd : Form
    {
        public katagoriadd()
        {
            InitializeComponent();
        }
        DataConnection db = DBTooll.DBInstance;

        private void button3_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox1.Text))
            {
                MainCatagory maincatagori = new MainCatagory();
                Product product = new Product();
                maincatagori.MainCategory = textBox1.Text;
                db.Maincatagory.Add(maincatagori);
                db.SaveChanges();
                MessageBox.Show("Eklendi");
                this.Close();
                Add a = new Add();
                a.Show();
            }
            else
            {
                MessageBox.Show("Lütfen bir isim girin");
            }
        }

        private void katagoriadd_FormClosing(object sender, FormClosingEventArgs e)
        {
            Add a = new Add();
            a.Show();
        }
    }
}
