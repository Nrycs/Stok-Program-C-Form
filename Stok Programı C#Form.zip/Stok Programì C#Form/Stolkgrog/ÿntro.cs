﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Stolkgrog
{
    public partial class İntro : Form
    {
        public İntro()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
            bool islem = false;

        private void timer1_Tick(object sender, EventArgs e)
        {

                if (!islem)
                {
                    this.Opacity += 0.0039;
                    if (this.Opacity == 1.0)
                    {
                        islem = true;
                    }
                }
                if (islem)
                {

                    this.Opacity -= 0.0039;
                    if (this.Opacity == 0)
                    {

                        Login srg = new Login();
                        srg.Show();
                        timer1.Enabled = false;
                        this.Hide();
                    }
                }
            }
    }
}
